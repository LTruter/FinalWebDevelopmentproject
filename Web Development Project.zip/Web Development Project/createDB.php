<?php
	/*
	Filename: createDB.php 
	Author: Lario Truter
	Created: 02 February 2024
	Description: Creates a database.
	*/

	// Create database if it doesn't exists
	// sql statement to create the database if it does not exist
	$sql = "CREATE DATABASE IF NOT EXISTS products";
	
	// Stores the result of the query (if it was sucessful or not)
	$result = $conn->query($sql);
	
	// Checks if the variable stored the value of "true"
	if($result) {
		
		// echo "Database created successfully";
		
	} else {
		
		// echo "Error creating database: " . $conn->error;
		
	}

?>
