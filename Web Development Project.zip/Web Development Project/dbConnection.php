<?php
	/*
	Filename: dbConnection.php 
	Author: Lario Truter
	Created: 02 February 2024
	Description: Function to create a database connection.
	*/ 

	// Storing the code in a function will keep the code more organised and reusable
	// Function to create the connection object
	function createConnection() {
		
		// Store the connection information to variables
		$servername = "localhost";
		$username = "root";
		$password = "";

		// Create connection
		$conn = new mysqli($servername, $username, $password);

		// Check if there are any errors with the connection
		if($conn->connect_error) {
			
			die("Connection failed: " . $conn->connect_error);
			
		}
	
		// Returns the connection object
		return $conn;
	
	}

?>