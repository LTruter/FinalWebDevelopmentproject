<?php
	/*
	Filename: validateXML.php 
	Author: Lario Truter
	Created: 02 February 2024
	Description: Validates a parsed xml file and stores it to the database.
	*/

	// Starts or resumes a session 
	session_start();

	// The file to create the connection object
	require_once("dbConnection.php");

	// Call the function to create the connection object and store it to a variable
	$conn = createConnection();

	// The file to create the database
	require_once("createDB.php");

	// The file to create the table
	require_once("createTable.php");

	// Stores the submitted file to a variable
	$uploadedXML = $_FILES["xmlFile"];

	// Checks if a file was submitted 
	// If the file size is not 0, then that means a file was uploaded
	if($uploadedXML["size"] != 0){

		// Gets the file extension of the uploaded file ans stores it to a variable
		// $uploadedXML["name"] is the file name including the extension
		// pathinfo(the file name or path, the specific information you want to retrieve)
		// PATHINFO_EXTENSION is a constant of pathinfo that will retrieve the file extension
		// strtolower converts the file extension to lower case since file extensions are case sensitive
		$fileExtension = strtolower(pathinfo($uploadedXML["name"], PATHINFO_EXTENSION));

		// Checks if the file extension is xml
		if($fileExtension == "xml"){

			// Creates new DOMDocument object (DOMDocument is used for creating, manipulating and working with XML documents) and stores it to a variable
			$dom = new DOMDocument;

			// Store the ["tmp_name"] of ["xmlFile"] to variable
			// ["tmp_name"] is temporary file path to the uploaded file
			$tmpName = $_FILES["xmlFile"]["tmp_name"];
			
			// Loads the xml document so it needs the temporary file path
			$dom->load($tmpName);

			// Checks if the xml document was loaded successfully
			if($dom){

				// Stores the elements with the specified tag name (in the loaded xml document) to the variable as an array
				$products = $dom->getElementsByTagName('product');

				// Checks if there are any product tags stored to the variable
				// Access the length property of the products variable to check if the length is NOT equal to 0
				if($products->length !== 0) {
				
					// Iterates through each element in the variable array 
					// This loop will be checking if the file contents fail any of the validation checks and if it does, the file will be considered invalid
					foreach($products as $product) {

						// Stores the attribute values to variables
						$category = $product->getAttribute('category');
						$name = $product->getAttribute('name');
						$price = $product->getAttribute('price');
						$quantity = $product->getAttribute('quantity');
						$image = $product->getAttribute('image');

						// Check if any of the variables are empty and if 
						if(empty($category) || empty($name) || empty($price) || empty($quantity) || empty($image)) {
							
							// Stores the validation message to a variable in the $_SESSION global array
							$_SESSION["validationErr"] = "One or more product fields are empty";
							
							header("Location: createXML.php");
											
							exit();
												
						} else{
						
							// Check that the price and quantity fields do NOT match the regular expression
							// preg_match(the regex, the variable string that will be checked)
							// "/" opening and closing, "^" ensures the matching starts from the beginning of the string, "\d" represents digits, 
							// "+" must be one or more occurences of the previous character, "$" ensures the matching continues until the end of the string
							if(!preg_match("/^\d+$/", $price) || !preg_match("/^\d+$/", $quantity)) {
						
								// Stores the validation message to a variable in the $_SESSION global array
								$_SESSION["validationErr"] = "Price and Quantity must only contain digits.";
								
								header("Location: createXML.php");
												
								exit();
								
							} else {
							
								// Define an array with accepted image extensions
								$acceptedExtensions = ["jpg", "png", "jpeg"];
								
								// Get the image attribute extension and convert it to lowercase
								$imgAttrExtension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
							
								// Checks if the image attribute extension is NOT in the array
								// in_array(what you are looking for in the array, the array to search)
								if(!in_array($imgAttrExtension, $acceptedExtensions)){
								
									// Stores the validation message to a variable in the $_SESSION global array
									// implode converts arrays to a form where they can be displayed 
									// implode("what will be used to separate the array items", the array to be converted)
									$_SESSION["validationErr"] = "Image extension must be: " . implode(", ", $acceptedExtensions);
									
									header("Location: createXML.php");
													
									exit();
								
								}
							}
						}
					}
					
								
					// Stores the products to the database since the file is valid
					foreach($products as $product) {

						// Stores the attribute values to variables
						$category = $product->getAttribute('category');
						$name = $product->getAttribute('name');
						$price = $product->getAttribute('price');
						$quantity = $product->getAttribute('quantity');
						$image = $product->getAttribute('image');

						// sql statement to checks if the product category and name already exist in the table
						$sql = "SELECT * FROM product WHERE product_category = ? AND product_name = ?";

						// Use prepared statement to prevent SQL injection
						$stmt = $conn->prepare($sql);
						
						// Bind the parameters to the prepared statement
						$stmt->bind_param("ss", $category, $name);

						// Execute the statement	
						$stmt->execute();
						
						// Store the result set to a variable 
						// get_result() gets the result set from a query so that I can work with it
						$result = $stmt->get_result();
						
						// If statement checks the $result variable to see if only 1 row matches the requirements
						// This prevents it from matching over multiple rows
						if($result->num_rows == 1){
							
							// Prepared statement that updates only the price and quantity in the table
							$update = $conn->prepare("UPDATE product SET product_price = ?, product_quantity = ? WHERE product_category = ? AND product_name = ?");
							
							// Bind the parameters to the prepared statement
							$update->bind_param("diss", $price, $quantity, $category, $name);
							
							// Execute the prepared statement
							$update->execute();					
							
						} else {
							
							// If there is no matching row, insert the data as another row in the table
							// SQL statement to insert the XML data into the table
							$sql = "INSERT INTO product (product_category, product_name, product_price, product_quantity, image_path) VALUES (?, ?, ?, ?, ?)";
							
							// Use prepared statement to prevent SQL injection
							$stmt = $conn->prepare($sql);

							// Bind the parameters to the prepared statement
							$stmt->bind_param("ssdis", $category, $name, $price, $quantity, $image);
														
							// Execute the statement	
							$stmt->execute();
						}
					}
					
					// Close the prepared statement
					$stmt->close();
					
					// Close Database Connection
					$conn->close();
					
					// Stores the validation message to a variable in the $_SESSION global array
					$_SESSION["validSuccess"] = "Products stored to database successfully.";
					
					header("Location: createXML.php");
									
					exit();

				} else {

					// Stores the validation message to a variable in the $_SESSION global array
					$_SESSION["validationErr"] = "No products found.";
					
					header("Location: createXML.php");
									
					exit();
				
				}
					
			} else {
				
				// Stores the validation message to a variable in the $_SESSION global array
				$_SESSION["validationErr"] = "Invalid XML document: " . $conn->error;
				
				header("Location: createXML.php");
								
				exit(); 
				
			}
			
		} else {
			
			// Stores the validation message to a variable in the $_SESSION global array
			$_SESSION["validationErr"] = "File must be an xml file.";
			
			header("Location: createXML.php");
							
			exit();
			
		}
			
	} else {
		
		// Stores the validation message to a variable in the $_SESSION global array
		$_SESSION["validationErr"] = "No file was submitted.";
		
		header("Location: createXML.php");
						
		exit();
		
	}
?>