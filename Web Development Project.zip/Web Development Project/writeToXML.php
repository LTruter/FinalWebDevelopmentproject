<?php
	/*
	Filename: writeToXML.php 
	Author: Lario Truter
	Created: 02 February 2024
	Description: Writes the submitted product information to an xml file.
	*/

	// Starts or resumes a session 
	session_start();

	// Store the form data to variables
	$category = $_POST['category'];
	$name = $_POST['name'];
	$price = $_POST['price'];
	$quantity = $_POST['quantity'];
	$image = $_FILES['image'];

	// Checks if any of the form fields are empty
	// If even one of the form fields are empty, the if statement will evaluate to true and run
	// If they all evaluate to false, the else statement will run
	// If $image['size'] == 0 then that means no file was uploaded
	if(empty($category) || empty($name) || empty($price) || empty($quantity) || $image['size'] == 0) {

		// Stores the error message to the variable in the $_SESSION global array
		$_SESSION["emptyForm"] = "One or more form fields are empty.";
		
		// Redirect back to createXML
		header('Location: createXML.php');
		
		// Terminates the script so that no more code will run
		exit();
		
	} else {
		
		// Creates new DOMDocument object (DOMDocument is used for creating, manipulating and working with XML documents) and stores it to a variable
		$dom = new DOMDocument();
		
		// Checks if the file exists
		if (file_exists('products.xml')) {
		
			// The file is loaded
			$dom->load('products.xml');
		  
		} else {
		
			// Creates element and assigns it to the variable
			$root = $dom->createElement('products');
		  
			// Makes the element a child of the XML document
			// This will make it a root element (the highest level tag, like the html tags in html)
			$dom->appendChild($root);
		}

		// Create an element that will be the child of the root element
		$product = $dom->createElement('product');
		
		// Set the attributes for the created element
		// setAttribute(attribute name, attribute value)
		$product->setAttribute('category', $category);
		$product->setAttribute('name', $name);
		$product->setAttribute('price', $price);
		$product->setAttribute('quantity', $quantity);

		// Create the upload directory
		$uploadDir = "Uploads/";

		// Checks if the variable is NOT a directory
		if(!is_dir($uploadDir)) {
			
			// mkdir(the directory I want to create, 0755 = gives the directory "read, write and execute permissions", 
			// true = will create the directory and its parent directories(if necessary) is used to create a directory
			mkdir($uploadDir, 0755, true);
			
		}

		// Stores the path to the temporary location of the image when it was first uploaded 
		$imageTmpName = $image['tmp_name'];

		// Stores the image name or image path
		$imageName = $image['name'];
		
		// pathinfo returns info about a file path
		// PATHINFO_EXTENSION tells pathinfo to return only the file extension part of the path
		$imageExtension = pathinfo($imageName, PATHINFO_EXTENSION);

		// The image name and extension stored to the variable
		$imageName = $name . "." . $imageExtension;

		// By concatenating, I've created the full path to where I want to store the uploaded image
		$imagePath = $uploadDir . $imageName;
		
		// Checks if the image was moved to the directory where you will be storing the uploaded images
		// move_uploaded_file(takes the tmp_name, the directory where you want to move the image to)
		// tmp_name is the path to the temporary location of the image when it was first uploaded 
		if(move_uploaded_file($imageTmpName, $imagePath)){
			
			// echo "Moved image file to directory";
			
		}
		
		// Sets the image attribute for the element
		$product->setAttribute('image', $imagePath);

		// documentElement gets the root element
		// This line of code is making the specified element a child of the root element
		$dom->documentElement->appendChild($product);

		// Writes the contents of the DOMDocument ($dom) to the specified file
		$dom->save('products.xml');

		// Stores the success message to the variable in the $_SESSION global array
		$_SESSION["formStored"] = "Product successfully stored to 'products.xml' file.";
		
		// Redirect back to createXML
		header('Location: createXML.php');
		
		// Terminates the script so that no more code will run
		exit();
	}
?>
