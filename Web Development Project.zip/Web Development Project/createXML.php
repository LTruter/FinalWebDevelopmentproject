<!DOCTYPE html>
	<!--
	Filename: createXML.php 
	Author: Lario Truter
	Created: 02 February 2024
	Description: Form for submitting product information, submitting a xml file to be validated and displays a table with all the products stored to the xml file.
	-->

<?php
	// Starts or resumes session
	session_start();
?>
<html>
	<head>
	  <title> Shop-Ok Supermarket </title>
	  <script src="javascript.js"></script>
	  <style>
		/* Styling for the body */
		body{
			font-size: 24px;
			margin: 0px;
		}
	  
		/* Styling for the header */
		header{
			text-align: center;
			background-color: #3498db;	
			padding: 20px;
		}
		
		/* Styling for the website name */
		#shop-name{
			color: #fff;
			font-family: arial;
			margin: 0px;
		}
		
		/* Styling for the main tag */
		.grid-container{
			display: grid;
			justify-content: center; 
		}
		
		/* Styling for the error message */
		.error-msg{
			color: red;
		}
		
		/* Styling for the success message */
		.success-msg{
			color: green;
		}
		
		/* Styles buttons and file chooser */
		button, .sub-button, #image, #xml-file{
			font-size: 18px;
			padding: 5px;
		}
		
		/* Styling for "Input Product" file chooser and "Validate File" file chooser */
		#image, #xml-file{
			margin-bottom: 10px;
		}
		
		/* Styling for form inputs */
		#category, #name, #price, #quantity{
			font-size: 18px;
			margin-bottom: 5px;
		}
		
		/* Styling for the Inventory table container */
		#table-container{
			margin-bottom: 5%;		
		}
		
		/* Styling for the Inventory table */
		table, th, td{
			border: solid 1px;
			border-collapse: collapse;		/* Makes the borders 1 line instead of the double lines */
		}
		
		/* Styling for the Inventory table */
		th, td{
			text-align: center;
			padding: 10px;
		}
		
		/* Styling for the footer */
		footer{
			text-align: center;
			padding: 20px;
			background-color: #3498db;
		}
		
		/* Styling for the copyright information */
		#copyright{
			color: #fff;
		}
	  </style>
	</head>
	
	<body>
		<header>
			<div><h1 id="shop-name"> Shop-Ok Supermarket </h1></div>
		</header>

		<main class="grid-container">
			<div class="grid-item">
				<h1> Input Product: </h1>
			</div>
		
			<?php
						
				// Checks if the validation variable is set in the $_SESSION global array
				if(isset($_SESSION["emptyForm"])) {

					// Displays the error message of the validation
					echo "<div class='error-msg'>" . $_SESSION["emptyForm"] . "</div>";
					
					// Unset the session variable to clear the message (otherwise it just keeps displaying)
					unset($_SESSION["emptyForm"]);
	
				} 
				
				// Checks if the validation variable is set in the $_SESSION global array
				if(isset($_SESSION["formStored"])) {

					// Displays the error message of the validation
					echo "<div class='success-msg'>" . $_SESSION["formStored"] . "</div>";	

					// Unset the session variable to clear the message (otherwise it just keeps displaying)
					unset($_SESSION["formStored"]);
				
				} 
			
			?>
		
			<form id="productForm" method="POST" enctype="multipart/form-data" action="writeToXML.php">
				<div class="grid-item">
					<label for="category"> Category: </label>
						<input type="text" id="category" name="category">
				</div>

				<div class="grid-item">
					<label for="name"> Name: </label>
						<input type="text" id="name" name="name">
				</div>

				<div class="grid-item">
					<label for="price"> Price: </label>
						<input type="text" id="price" name="price">
				</div>

				<div class="grid-item">
					<label for="quantity"> Quantity: </label>
						<input type="number" id="quantity" name="quantity" >
				</div>
					
				<div class="grid-item">
					<input type="file" id="image" name="image" >
				</div>

				<div class="grid-item">
					<input type="submit" class="sub-button" value="Store products">
				</div>
			</form>
			
			<div class="grid-item">
				<h1> Validate File: </h1>
			</div>
			
			<?php
			
				// Checks if the validation variable is set in the $_SESSION global array
				if(isset($_SESSION["validationErr"])) {

					// Displays the error message of the validation
					echo "<div class='error-msg'>" . $_SESSION["validationErr"] . "</div>";
					
					// Unset the session variable to clear the message (otherwise it just keeps displaying)
					unset($_SESSION["validationErr"]);
	
				} 
				
				// Checks if the validation variable is set in the $_SESSION global array
				if(isset($_SESSION["validSuccess"])) {

					// Displays the error message of the validation
					echo "<div class='success-msg'>" . $_SESSION["validSuccess"] . "</div>";	

					// Unset the session variable to clear the message (otherwise it just keeps displaying)
					unset($_SESSION["validSuccess"]);
				
				}
					
			?>
			
			<form method="POST" enctype="multipart/form-data" action="validateXML.php">
				<div class="grid-item">
					<input type="file" id="xml-file" name="xmlFile">
				</div>
				
				<div class="grid-item"> 
					<input type="submit" class="sub-button" value="Validate">
				</div>
			</form>
			
			<h1> Inventory: </h1>
			<!-- I can use this tag and its id for the table I've made in javascript so that I can use appendChild to make it the child of this id -->
			<div id="table-container">
			
			</div>			
		</main>

		<footer>
			<div id="copyright"> &copy 2024 Shop-Ok Supermarket </div>
		</footer>		
	</body>
</html>