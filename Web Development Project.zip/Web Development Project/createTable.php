<?php
	/*
	Filename: createTable.php 
	Author: Lario Truter
	Created: 02 February 2024
	Description: Creates a table.
	*/

	// Select the database
	// This selected database will now be assigned to the connection as the database that queries are sent to
	// This will be changed if select_db() is used again to change it or if the connection is closed
	$conn->select_db("products");


	// sql statement to create table if it does not exist
	// DECIMAL(the total number of digits, the number of decimal digits as part of the total) 
	$sql = "CREATE TABLE IF NOT EXISTS product (
		product_id INT AUTO_INCREMENT PRIMARY KEY,
		product_category VARCHAR(255) NOT NULL,
		product_name VARCHAR(255) NOT NULL,
		product_price DECIMAL(10, 2) NOT NULL,
		product_quantity INT NOT NULL,
		image_path VARCHAR(255) NOT NULL
	)";

	// Stores the result of the query (if it was sucessful or not)
	$result = $conn->query($sql);

	// Checks if the variable stored the value of "true"
	if ($result) {
		
		// echo "Table created successfully";
		
	} else {
		
		// echo "Error creating table: " . $conn->error;
		
	}

?>