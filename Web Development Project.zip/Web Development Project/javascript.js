	/*
	Filename: javascript.js 
	Author: Lario Truter
	Created: 02 February 2024
	Description: Creates a table and displays the xml file product information in it.
	*/

	// When the entire window (browser window/tab) is finished loading, the function is executed which calls the displayProducts() function
	window.onload = function() {
		
		// Calls the displayProducts() function
		displayProducts();
	};

	// Function to retrieve the XML document from the server
	function displayProducts() {
	  
		// XMLHttpRequest() creates a connection to "localhost" to retrieve or send data
		// XMLHttpRequest() object is stored to the variable 
		var xmlhttp = new XMLHttpRequest();

		// Set up a callback function to handle the response
		xmlhttp.onreadystatechange = function() {

			// Check if the request is complete (readyState 4)
			if(this.readyState === 4) {

				// Check if status of the request is successful (status 200)
				if(this.status === 200) {
					
					// Stores the XMLHttpRequest() response to a variable
					// The response is the XML document that I specified when I initialised the request
					var xmlDoc = this.responseXML;

					// Check if xmlDoc is not null 
					if (xmlDoc) {
						
						// Call the createTable function with the parsed XML document
						createTable(xmlDoc);
					  
					} else {
						
						// console.error() is used specifically for logging error messages
						console.error('Error parsing XML');
					  
					}
					
				} else {
					
					// Displays the error message and the status of the request
					console.error('Failed to retrieve XML data. Status: ' + this.status);
				
				}
			}
		}
	  
	  // The XML document must be fetched from the server using the XMLHttpRequest() object 
	  // .open is used to initialise the request
	  // .open("HTTP method to use to send the request", "the file I want to fetch", whether or not the request should be asynchronous)
	  xmlhttp.open("GET", "products.xml", true);
	  
	  // .send is used to send the request.
	  xmlhttp.send();
	}

	// Function that creates the table that will display the retrieved XML document
	function createTable(xmlDoc) {
		
		// Stores all the elements with the specified tag name to the array
		var products = xmlDoc.getElementsByTagName("product");

		// Creates the table element in the document of HTML document that links to it
		var table = document.createElement("table");
		
		// Creates the <thead> element which groups and defines the header section. The <th> is included in this grouping
		var header = table.createTHead();
		
		// Inserts a <tr> into <thead>
		// insertRow(0) specifies that the row should be the first one inserted into the <thead>
		var row = header.insertRow(0);
		
		// Stores the category names in the array to the variable
		var categories = ["Category", "Name", "Price", "Quantity", "Image"];

		// Loop that sets the index value to 0 and will continue to loop and increment the index value until the index value is NOT less than the categories array length value
		// This loop is for the <thead> section
		for (var i = 0; i < categories.length; i++) {
			
			// Creates the <th> element
			var th = document.createElement("th");
			
			// .innerHTML represents the content between the specified opening and closing tag
			// The category name with the specified index value in the array will be displayed in the <th> tag content
			th.innerHTML = categories[i];
			
			// Appends the th variable as a child of the row variable
			row.appendChild(th);
		}

		// Will loop until index value is NOT less than the products array length
		// This loop is for the <td>
		for (var i = 0; i < products.length; i++) {
			
			// Stores the item in the products array, with the specified index value, to the variable
			var product = products[i];
			
			// .insertRow(-1) adds the new row to the end of the table
			var tr = table.insertRow(-1);

			// Gets the product attribute and stores it to a variable
			var category = product.getAttribute("category");
			var name = product.getAttribute("name");
			var price = product.getAttribute("price");
			var quantity = product.getAttribute("quantity");
			var image = product.getAttribute("image");

			// tr.insertCell() inserts a cell(<td>) in the row at the index specified
			var td1 = tr.insertCell(0);
			
			// The category variable value is inserted into the content of the td1 variable
			// So the category variable value is inserted as the content of the first <td> tag in the <tr>
			td1.innerHTML = category;

			var td2 = tr.insertCell(1);
			td2.innerHTML = name;

			var td3 = tr.insertCell(2);
			td3.innerHTML = price;

			var td4 = tr.insertCell(3);
			td4.innerHTML = quantity;

			// The fifth <td> in the row and the last, since there were only 5 attributes
			var td5 = tr.insertCell(4);
			
			// Creates the img element in the document
			var img = document.createElement("img");
			
			// The img src is stored in the image variable
			img.src = image; 
			
			// The img alt text will be the value in the name variable
			img.alt = name;
			
			// .style allows me to edit the css of the img
			img.style.width = "50px"; 
			
			// img variable is appended to the <td> 
			// innerHTML is used for replacing the content of the element with new content (<td><img></td>
			// appendChild is used when you want to add a child to the element, but keep the existing content of the element (<td> existing content <img></td>) 
			td5.appendChild(img);
		}

		// Append the table as a child of the element with the following id
		document.getElementById("table-container").appendChild(table);
	}